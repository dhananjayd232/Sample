print("Hello Util")

def test():
	print("in test function")